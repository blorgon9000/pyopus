#!/usr/bin/env python

#   FILE: master_test.py -- Master portion of a test suite for pypvm.
# AUTHOR: W. Michael Petullo, wp0002@drake.edu
#   DATE: 18 FEB 1998
#
# Copyright (c) 1999 W. Michael Petullo
# All rights reserved.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import pypvm
import sys
import os
from signal import SIGTERM
from sys import stdout
from time import sleep

try:

# ============================ test mytid () ==================================
	my_tid = pypvm.mytid ()
	print "MASTER: my tid = %s" % my_tid

# ============================ test get/setopt () =============================
	print "MASTER: testing get/setopt ()"
	val = pypvm.setopt (pypvm.opt['Route'], pypvm.getopt (pypvm.opt['Route']))
	print "PvmRoute =", val

# ============================ test catchout () ===============================
	print "MASTER: setting catchout to stdout..."
	pypvm.catchout (stdout)

# ============================ test delhosts () ===============================
# print "MASTER: removing host hopper..."
# pypvm.delhosts (["hopper"])

# ============================ test addhosts () ===============================
# print "MASTER: adding host hopper..."
# pypvm.addhosts (["hopper"])

# ============================ test spawn () ==================================
	print "MASTER: spawning 2 tasks (slave_test.py)..."
	tids = pypvm.spawn (os.getcwd() + "/slave_test.py", [], pypvm.spawnOpts['TaskDefault'], "", 2)
	print "MASTER: spawned task's tid = %s" % tids

# ============================ test notify () =================================
	print "MASTER: asking for notification on child exits..."
	pypvm.notify (pypvm.notifyDict['TaskExit'], 2, tids, 1)

# ============================ test initsend () ===============================
	print "MASTER: initializing message buffer to PvmDataDefault..."
	pypvm.initsend (pypvm.data['default'])

# ============================ test mkbuf () ==================================
	print "MASTER: testing mkbuf ()..."
	newrbuf = pypvm.mkbuf (pypvm.data['default'])
	newsbuf = pypvm.mkbuf (pypvm.data['default'])

# ============================ test get[rs]buf () =============================
	print "MASTER: testing get[rs]buf ()..."
	oldrbuf = pypvm.getrbuf ()
	oldsbuf = pypvm.getsbuf ()

# ============================ test set[rs]buf () =============================
	print "MASTER: testing set[rs]buf ()..."
	pypvm.setrbuf (newrbuf)
	pypvm.setsbuf (newsbuf)

# ============================ test freebuf () ================================
	print "MASTER: testing freebuf ()..."
	pypvm.freebuf (oldrbuf)
	pypvm.freebuf (oldsbuf)

# ============================ test pk () =====================================
	data = {-1: [1, (2, 3, 4), 4]}
	print ("MASTER: packing %s..." % data)
	pypvm.pk (data)

# ============================ test send () ===================================
	for recipient in tids:
		print ("MASTER: sending data to tid %s..." % recipient)
		pypvm.send (recipient, 1)

# ============================ test mcast () ==================================
	print "MASTER: initializing message buffer to PvmDataDefault..."
	pypvm.initsend (pypvm.data['default'])

	data = ['1', '2', '3']
	print ("MASTER: packing %s using pkbyte ()..." % data)
	pypvm.pkbyte (data, 1)

	#data = [1.0123456789, -2, 3.14]
	#print ("MASTER: packing %s using pkcplx ()..." % data)
	#pypvm.pkcplx (data, 1)

	#data = [1.0123456789, -2, 3.14]
	#print ("MASTER: packing %s using pkdcplx ()..." % data)
	#pypvm.pkdcplx (data, 1)

	data = [1.0123456789, -2, 3.14]
	print ("MASTER: packing %s using pkdouble ()..." % data)
	pypvm.pkdouble (data, 1)

	data = [1.0123456789, -2, 3.14]
	print ("MASTER: packing %s using pkfloat ()..." % data)
	pypvm.pkfloat (data, 1)

	data = [1, -2, 3]
	print ("MASTER: packing %s using pkint ()..." % data)
	pypvm.pkint (data, 1)

	data = [1, -2, 3]
	print ("MASTER: packing %s using pklong ()..." % data)
	pypvm.pklong (data, 1)

	data = [1, -2, 3]
	print ("MASTER: packing %s using pkshort ()..." % data)
	pypvm.pkshort (data, 1)

	pypvm.mcast (tids, 2)

# ============================ test config () =================================
	print "MASTER: results from config:", pypvm.config (1)

# ============================ test tasks () ==================================
	print "MASTER: results from tasks:", pypvm.tasks (0)

# ============================ test tidtohost () ==============================
	print "MASTER: results from tidtohost:", pypvm.tidtohost (my_tid)

# ============================ test pypvm exception ===========================
	try:
		pypvm.send (-1, 0)
		print "MASTER: deliberate error didn't throw and exception (bad!)"
	except:
		print "MASTER: deliberate send exception caught"

# ============================ sleep ==========================================
	print "MASTER: sleeping for 2 seconds (so slaves can catch up)..."
	sleep (2)

# ============================ test sendsig () ================================
	print "MASTER: sending SIGTERM to children..."
	for tid in tids:
		pypvm.sendsig (tid, SIGTERM)

# ============================ test nrecv () ==================================
	print "MASTER: calling nrecv ()..."
	pypvm.nrecv (tids[0], 1)

# ============================ test trecv () ==================================
# NOTE: this also serves to sleep for 10 seconds, since no message is coming.
	print "MASTER: calling trecv ()..."
	pypvm.trecv (10,tids[0],1)

# ============================ test kill () ===================================
	print "MASTER: killing slaves..."
	for tid in tids:
		pypvm.kill (tid)

# ============================ receive exit notification ======================
# NOTE: This is in conjunction with the notify test above.
	for tid in tids:
		pypvm.recv (-1, 2)
		print "MASTER: received an exit notification..."

# ============================ test exit () ===================================
	print "MASTER: exiting pvm..."
	pypvm.exit ()

except:
	print "A pypvm error occured!"
	a =  sys.exc_info()
	print str(a[0])
	print a[1]
