#!/usr/bin/env python

#   FILE: slave_test.py -- Slave portion of a test suite for pypvm.
# AUTHOR: W. Michael Petullo, wp0002@drake.edu
#   DATE: 18 FEB 1998
#
# Copyright (c) 1999 W. Michael Petullo
# All rights reserved.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import pypvm
import sys
from signal import signal, SIGTERM
from time import sleep

# ============================ sig_h () =======================================
def sig_h (signum, traceback):
	print "SLAVE: got signal", signum
try: 

	signal (SIGTERM, sig_h)

# ============================ test parent () =================================
	parent = pypvm.parent ()

# ============================ test probe () ==================================
	print "SLAVE: testing probe..."
	bufid = pypvm.probe (parent, 1)
	print "SLAVE: probe returned", bufid

# ============================ test bufinfo () ================================
	print "SLAVE: testing bufinfo..."
	if bufid:
		print "SLAVE: bufinfo returned", pypvm.bufinfo (bufid)
	else:
		print "SLAVE: no incoming messages"

# ============================ test recv () ===================================
	print "SLAVE: receiving data from tid %s..." % parent
	pypvm.recv (parent, 1)

# ============================ test up () =====================================
	print "SLAVE: unpacking data..."
	data = pypvm.upk ()
	print "SLAVE: data received = %s" % data

# ============================ test mcast () ==================================
	print "SLAVE: receiving data from tid %s (mcast test)..." % parent
	pypvm.recv (parent, 2)

	#data = pypvm.upkbyte (3, 1)
	#print "SLAVE: data received = %s using upkbyte ()" % data

	#data = pypvm.upkcplx (3, 1)
	#print "SLAVE: data received = %s using upkcplx" % data

	#data = pypvm.upkdcplx (3, 1)
	#print "SLAVE: data received = %s using upkdcplx" % data

	data = pypvm.upkdouble (3, 1)
	print "SLAVE: data received = %s using upkdouble" % data

	data = pypvm.upkfloat (3, 1)
	print "SLAVE: data received = %s using upkfloat" % data

	data = pypvm.upkint (3, 1)
	print "SLAVE: data received = %s using upkint" % data

	data = pypvm.upklong (3, 1)
	print "SLAVE: data received = %s using upklong" % data

	data = pypvm.upkshort (3, 1)
	print "SLAVE: data received = %s using upkshort" % data

# ============================ sleep ==========================================
	print "SLAVE: sleeping so I don't miss the signal"
	try:
		sleep (2)
	except IOError:
		# interrupted system call
		pass

# ============================ test exit () ===================================
	print "SLAVE: exiting pvm..."
	pypvm.exit ()

except:
	print "A pypvm error occured!"
	print sys.exc_info()
