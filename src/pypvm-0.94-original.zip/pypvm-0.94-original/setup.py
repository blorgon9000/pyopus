"""
 setup.py: This is a setup file for Python's Distutils
           installion system.

 Created: November 26, 2002 Sam Tannous

 If you need help, run "python setup.py --help" and
 "python setup.py --help-commands"

 for windows 2k (with Cygwin gcc), you need
 "python setup.py build --compiler=mingw32"

 for all other UNIX building, simply "python setup.py build" will suffice


 this builds various packages

    python setup.py bdist                  tar.gz file
    python setup.py bdist_wininst          win 2k install wizard exe
    python setup.py bdist_dumb             a tar.gz file to be untarred from /
    python setup.py bdist_rpm              two RPMs for Linux

    python setup.py build                  builds everything for an install
    python setup.py install                install everything 
    
 and usually puts RPMS, tgz, exe files in a directory called dist.
 See the Python Distutils web pages for more information on installing
 and other options:
  
    http://www.python.org/doc/current/lib/module-distutils.html

 $Revision: 1.3 $
 $Source: /cvsroot/pypvm/pypvm/setup.py,v $

"""
import sys
from distutils import sysconfig
from distutils.core import setup
from distutils.extension import Extension

prefix = sysconfig.PREFIX
inc_dirs = [prefix + "/include"]
lib_dirs = [prefix + "/lib"]
libs = ["pvm3","pvmtrc","fpvm3","gpvm3"]

setup(name="pypvm",
      version="0.94",
      description="Python Wrapper for PVM",
      author="W. Michael Petullo and Greg Baker",
      author_email="pypvm-discuss@lists.sourceforge.net",
      url="http://pypvm.sourceforge.net/",
      py_modules = ['pypvm'],
      ext_modules = [Extension(name="pypvm_core",
                               sources = ["pypvm_coremodule.c"],
                               include_dirs = inc_dirs,
                               libraries = libs,
                               library_dirs = lib_dirs)]
      )
    

